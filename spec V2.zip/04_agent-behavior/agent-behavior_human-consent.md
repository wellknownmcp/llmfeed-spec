# 🙋 Agent Behaviour: Human Consent

This module will define when and how agents should request user confirmation before acting on a feed.

(TBD — to be expanded)