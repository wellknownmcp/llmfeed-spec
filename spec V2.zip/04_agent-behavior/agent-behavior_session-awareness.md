# 🔁 Agent Behaviour: Session Awareness

This module will define how agents interpret session-aware feeds and interact across multiple steps.

(TBD — to be expanded)