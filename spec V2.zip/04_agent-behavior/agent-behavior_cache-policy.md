# 🧠 Agent Behaviour: Cache Policy

This module will define how long agents can cache feeds, when to revalidate signatures, and how to handle offline mode.

(TBD — to be expanded)