# 🛡️ Agent Behaviour: Certified-Only Mode

This module will define how agents should react when encountering feeds that are unsigned or not certified.

(TBD — to be expanded)