# ⚠️ Agent Behaviour: Risk Scoring

This module will define how to interpret and act on `risk_score`, `safety_tier`, or flags.

(TBD — to be expanded)